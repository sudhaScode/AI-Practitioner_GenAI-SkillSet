This contains screenshots that are used in the documentation (README files) across the repository. Please ignore.
