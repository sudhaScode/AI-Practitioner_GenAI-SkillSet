<script>
  import "../app.postcss";
</script>

<slot />
