#!/bin/bash

# set -euo pipefail

#./gemini-generic.sh "$1" 'Describe what you see factually, and also what you can infer from the context.'
./gemini-generic.sh "$1" 'Describe what you see'

